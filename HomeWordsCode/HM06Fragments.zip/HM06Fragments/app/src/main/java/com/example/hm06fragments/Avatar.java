package com.example.hm06fragments;

public class Avatar {
    public int avatarId;
    public int avatarSrc;

    public Avatar(int avatarId, int avatarSrc) {
        this.avatarId = avatarId;
        this.avatarSrc = avatarSrc;
    }
}
