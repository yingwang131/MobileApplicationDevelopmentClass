package com.example.hm4moviedatabase;

public class Test {
    public static void main(String[] args) {
        String item = String.valueOf(-1617183257);
        System.out.println(item);
    }
}
