package com.example.hm4moviedatabase;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {


    Button btnAddMovie;

    Button btnEditMovie;

    Button btnDelMovie;

    Button btnYear;

    Button btnRate;

    ArrayList<Movie> movieList = new ArrayList<Movie>();

    Map<String, Pair> movieMap = new HashMap<>();

    Map<String, Pair> movieIdMap = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnAddMovie = findViewById(R.id.button_add);
        btnEditMovie = findViewById(R.id.button_edit);
        btnDelMovie = findViewById(R.id.button_delete);
        btnYear = findViewById(R.id.button_year);
        btnRate = findViewById(R.id.button_rate);

        initiateMovieList();

        btnAddMovie.setOnClickListener(new Button.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, AddMovieActivity.class);
//                Bundle bundle = new Bundle();
//                bundle.putParcelableArrayList("movieList", movieList);
//
//                intent.putExtra(Constants.Movie_Key, bundle);
                startActivityForResult(intent, Constants.ADD_REQUEST_CODE);

            }
        });

        btnEditMovie.setOnClickListener(new Button.OnClickListener() {

            @Override
            public void onClick(View view) {
                final String[] listItems = new String[movieList.size()];
                int index = 0;
                for (Movie movie :
                        movieList) {
                    listItems[index++] = movie.getName();

                }
                //create dialog for selecting movie
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("Pick a Movie");
                builder.setItems(listItems, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int which) {
                        Intent intent = new Intent(MainActivity.this, EditMovieActivity.class);
                        Movie movie = movieMap.get(listItems[which]).movie;
                        intent.putExtra(Constants.MOVIE, movie);
                        startActivityForResult(intent, Constants.EDIT_REQUEST_CODE);
                        return;
                    }
                });

                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });

        btnDelMovie.setOnClickListener(new Button.OnClickListener() {

            @Override
            public void onClick(View view) {
                final String[] listItems = new String[movieList.size()];
                int index = 0;
                for (Movie movie :
                        movieList) {
                    listItems[index++] = movie.getName();

                }
                //create dialog for selecting movie
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("Pick a Movie");
                builder.setItems(listItems, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int which) {
                        Movie movie = movieMap.get(listItems[which]).movie;
                        movieList.remove(movie);
                        Iterator<String> idMapIterator = movieIdMap.keySet().iterator();
                        while (idMapIterator.hasNext()) {
                            if (idMapIterator.next() == movie.getId()) {
                                idMapIterator.remove();
                            }
                        }

                        Iterator<String> nameMapIterator = movieMap.keySet().iterator();
                        while (nameMapIterator.hasNext()) {
                            if (nameMapIterator.next().equals(movie.getName())) {
                                nameMapIterator.remove();
                            }
                        }

                        //call firebase API to delete movie
                        FireBaseUtil.delMovie(movie.getId());

                        Toast.makeText(MainActivity.this, movie.getName() + "has been removed successfully!", Toast.LENGTH_LONG).show();
                        return;
                    }
                });

                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });

        btnYear.setOnClickListener(new Button.OnClickListener() {

            @Override
            public void onClick(View view) {

                if (!movieList.isEmpty()) {
                    Intent intent = new Intent(MainActivity.this, YearActivity.class);
                    //sort movie list by year
                    Collections.sort(movieList, new Comparator<Movie>() {
                        @Override
                        public int compare(Movie a, Movie b) {
                            return a.getYear() - b.getYear();
                        }
                    });
                    intent.putParcelableArrayListExtra(Constants.Movie_LIST, movieList);
                    startActivityForResult(intent, Constants.YEAR_CODE);
                } else {
                    Toast.makeText(MainActivity.this, "movie list is empty", Toast.LENGTH_LONG).show();
                }
            }
        });

        btnRate.setOnClickListener(new Button.OnClickListener() {

            @Override
            public void onClick(View view) {
                if (!movieList.isEmpty()) {
                    Intent intent = new Intent(MainActivity.this, RatingActivity.class);
                    //sort movie list by rate
                    Collections.sort(movieList, new Comparator<Movie>() {
                        @Override
                        public int compare(Movie a, Movie b) {
                            return a.getRate() - b.getRate();
                        }
                    });
                    intent.putParcelableArrayListExtra(Constants.Movie_LIST, movieList);
                    startActivityForResult(intent, Constants.RATING_CODE);
                } else {
                    Toast.makeText(MainActivity.this, "movie list is empty", Toast.LENGTH_LONG).show();
                }
            }
        });

    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    /**
     *
     */
    private void initiateMovieList() {
        List<Movie> movies = FireBaseUtil.queryAll();
        movieList.addAll(movies);

        int idx = 0;
        for (Movie movie : movies) {
            Pair moviePair = new Pair(idx++, movie);
            movieMap.put(movie.getName(), moviePair);
            movieIdMap.put(movie.getId(), moviePair);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode) {
            case Constants.ADD_REQUEST_CODE:
                addMovie(data);
                break;
            case Constants.EDIT_REQUEST_CODE:
                editMoive(data);
            default:
                break;
        }

    }

    /**
     * edit movie call back method
     *
     * @param data
     */
    private void editMoive(Intent data) {
        Movie movie = data.getParcelableExtra(Constants.MOVIE);
        //remove old movie
        Movie oldMovie = movieIdMap.get(movie.getId()).movie;
        movieList.remove(oldMovie);
        // remove old relationship

        Iterator<String> nameMapIterator = movieMap.keySet().iterator();
        while (nameMapIterator.hasNext()) {
            if (nameMapIterator.next().equals(movie.getName())) {
                nameMapIterator.remove();
            }
        }

        movieList.add(movie);
        //update the movie
        movieIdMap.get(movie.getId()).movie = movie;
        movieMap.put(movie.getName(), new Pair(movieList.size() - 1, movie));
        System.out.println(movieList.size());
    }

    /**
     * add movie call back method
     *
     * @param data
     */
    private void addMovie(@Nullable Intent data) {
        Movie movie = data.getParcelableExtra(Constants.MOVIE);
        movie.setId(UUID.randomUUID().toString());
        movieList.add(movie);
        Pair moviePair = new Pair(movieList.size() - 1, movie);
        //
        movieMap.put(movie.getName(), moviePair);
        //
        movieIdMap.put(movie.getId(), moviePair);
        System.out.println(movieList.size());
    }

    /**
     * store the movie information and its position in the movie list
     */
    private class Pair {
        Movie movie;
        int position;

        Pair(int position, Movie movie) {
            this.position = position;
            this.movie = movie;
        }
    }
}
