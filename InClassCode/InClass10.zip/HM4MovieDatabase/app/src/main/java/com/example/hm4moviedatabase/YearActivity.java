package com.example.hm4moviedatabase;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class YearActivity extends AppCompatActivity {

    ArrayList<Movie> movieList;


    TextView tvMovieName;
    TextView tvMovieDescr;
    TextView tvGenre;
    TextView tvRating;
    TextView tvYear;
    TextView tvimdb;


    ImageView ivFirst;
    ImageView ivPrevious;
    ImageView ivNext;
    ImageView ivLast;

    Button btnFinish;

    int currentIndex = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        movieList = getIntent().getParcelableArrayListExtra(Constants.Movie_LIST);
        initiateUI();

        addListeners();
    }

    /**
     *
     */
    private void addListeners() {
        ivFirst.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (movieList.size() > 0) {
                    fillMovieInformation(movieList.get(0));
                    currentIndex = 0;
                }
            }
        });

        ivPrevious.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (movieList.size() > 0) {//assert the movie list is not empty
                    if (currentIndex == 0) {
                        Toast.makeText(YearActivity.this, "the current movie is the first movie", Toast.LENGTH_LONG).show();
                    } else {
                        fillMovieInformation(movieList.get(--currentIndex));
                    }
                }
            }
        });

        ivNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (movieList.size() > 0) {//assert the movie list is not empty
                    if (currentIndex == movieList.size() - 1) {
                        Toast.makeText(YearActivity.this, "the current movie is the last movie", Toast.LENGTH_LONG).show();
                    } else {
                        fillMovieInformation(movieList.get(++currentIndex));
                    }
                }
            }
        });

        ivLast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (movieList.size() > 0) {//assert the movie list is not empty
                    fillMovieInformation(movieList.get(movieList.size() - 1));
                    currentIndex = movieList.size() - 1;
                }
            }
        });

        btnFinish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                YearActivity.this.finish();
            }
        });
    }

    /**
     *
     */
    private void initiateUI() {
        setContentView(R.layout.activity_year);
        tvMovieName = findViewById(R.id.textView_movieNameY);
        tvMovieDescr = findViewById(R.id.textView_descMovieY);
        tvGenre = findViewById(R.id.tv_genreY);
        tvRating = findViewById(R.id.tv_rateY);
        tvYear = findViewById(R.id.tv_yearY);
        tvimdb = findViewById(R.id.tv_imdbY);

        ivFirst = findViewById(R.id.iv_firstMY);
        ivPrevious = findViewById(R.id.iv_previousY);
        ivNext = findViewById(R.id.iv_nextMY);
        ivLast = findViewById(R.id.iv_lastMY);

        btnFinish = findViewById(R.id.button_finishY);
        //show the content
        if (movieList.size() > 0) {
            Movie movie = movieList.get(0);
            fillMovieInformation(movie);
        }

    }

    /**
     * fill movie information into the textviews
     *
     * @param movie
     */
    private void fillMovieInformation(Movie movie) {
        tvMovieName.setText(movie.getName());
        tvMovieDescr.setText(movie.getDescription());
        tvGenre.setText(movie.getGenre());
        tvRating.setText(String.valueOf(movie.getRate()));
        tvYear.setText(String.valueOf(movie.getYear()));
        tvimdb.setText(movie.getImdb());
    }
}
