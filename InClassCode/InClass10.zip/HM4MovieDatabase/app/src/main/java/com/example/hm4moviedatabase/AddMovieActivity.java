package com.example.hm4moviedatabase;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.Map;

public class AddMovieActivity extends AppCompatActivity {

    EditText etMovieName;

    EditText etMovieDescr;

    SeekBar sbRate;

    EditText etYear;

    EditText etImdb;

    Button btnSave;

    TextView tvRate;

    Spinner spinnerGenre;

    int rate;

    String genre;

    String year;

    String imdb;

    String name;

    String describe;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_movie);

        btnSave = findViewById(R.id.button_save);

        etMovieName = findViewById(R.id.editText_movieName);

        etMovieDescr = findViewById(R.id.editText_describe);

        sbRate = findViewById(R.id.seekBar_rate);

        spinnerGenre = findViewById(R.id.spinner_genre);

        etYear = findViewById(R.id.editText_year);

        etImdb = findViewById(R.id.editText_imdb);

        tvRate = findViewById(R.id.tv_rate);

        //set value list  for genre component
        final ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.support_simple_spinner_dropdown_item, Constants.Genres);
        spinnerGenre.setAdapter(adapter);
        //get the genre type
        spinnerGenre.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
                genre = (String) adapterView.getItemAtPosition(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        //add lisener on seek bar
        sbRate.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean b) {
                rate = progress;
                tvRate.setText(String.valueOf(rate));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        btnSave.setOnClickListener(new Button.OnClickListener() {

            @Override
            public void onClick(View view) {
                //add  movie data into movieList
                name = etMovieName.getText().toString();
                describe = etMovieDescr.getText().toString();
                year = etYear.getText().toString();
                imdb = etImdb.getText().toString();

                //assert the condition of name and describe
                if (validateYear(year)) {
                    Movie movie = new Movie();
                    movie.setDescription(describe);
                    movie.setGenre(genre);
                    movie.setImdb(imdb);
                    movie.setRate(rate);
                    movie.setYear(Integer.valueOf(year));
                    movie.setName(name);

                    //return to main UI
                    Intent intent = new Intent();
                    intent.putExtra(Constants.MOVIE, movie);


                    //store to firebase
                    FireBaseUtil.insertMovie(movie);

                    setResult(Constants.ADD_REQUEST_CODE, intent);
                    finish();
                } else {
                    Toast.makeText(AddMovieActivity.this, "year must be numbers", Toast.LENGTH_LONG).show();
                }
            }

            private boolean validateYear(String year) {
                for (char val :
                        year.toCharArray()) {
                    if (!Character.isDigit(val)) {
                        return false;
                    }

                }
                return true;
            }
        });

    }
}
