package com.example.hm4moviedatabase;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * creat a Movie class to implments Parcelable to store moive imfomation
 */
public class Movie implements Parcelable {

    private String id;
    private String description;
    private String genre;
    private int rate;
    private int year;
    private String imdb;
    private String name;

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public int getRate() {
        return rate;
    }

    public void setRate(int rate) {
        this.rate = rate;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getImdb() {
        return imdb;
    }

    public void setImdb(String imdb) {
        this.imdb = imdb;
    }

    public Movie() {
        this.id = UUID.randomUUID().toString();

    }

    public Movie(String name, String description, String genre, int rate, int year, String imdb) {
        this.name = name;
        this.description = description;
        this.genre = genre;
        this.rate = rate;
        this.year = year;
        this.imdb = imdb;
        this.id = UUID.randomUUID().toString();
    }

    @Override
    public String toString() {
        return "Movie{" +
                "name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", genre='" + genre + '\'' +
                ", rate='" + rate + '\'' +
                ", year=" + year +
                ", imdb='" + imdb + '\'' +
                '}';
    }

    protected Movie(Parcel in) {
        name = in.readString();
        description = in.readString();
        genre = in.readString();
        rate = in.readInt();
        year = in.readInt();
        imdb = in.readString();
        id = in.readString();
    }

    public static final Creator<Movie> CREATOR = new Creator<Movie>() {
        @Override
        public Movie createFromParcel(Parcel in) {
            return new Movie(in);
        }

        @Override
        public Movie[] newArray(int size) {
            return new Movie[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(name);
        parcel.writeString(description);
        parcel.writeString(genre);
        parcel.writeInt(rate);
        parcel.writeInt(year);
        parcel.writeString(imdb);
        parcel.writeString(id);
    }

    public String getName() {
        return name;
    }


    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }


    public Map toHashMap() {
        Map<String, Object> movieMap = new HashMap<>();

        movieMap.put("name", this.name);
        movieMap.put("description", this.description);
        movieMap.put("genre", this.genre);
        movieMap.put("rate", this.rate);
        movieMap.put("year", this.year);
        movieMap.put("imdb", this.imdb);
        movieMap.put("id", this.id);
        return movieMap;
    }

    public Movie(Map movieMap) {
        this.name = (String) movieMap.get("name");
        this.description = (String) movieMap.get("description");
        this.genre = (String) movieMap.get("genre");
        this.rate = (int) (long) movieMap.get("rate");
        this.year = (int) (long) movieMap.get("year");
        this.imdb = (String) movieMap.get("imdb");
        this.id = (String) movieMap.get("id");


    }
}
