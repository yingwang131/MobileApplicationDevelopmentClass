package com.example.hm4moviedatabase;

public interface Constants {

    /**
     *
     */
    public final static String Movie_LIST = "movieList";
    /**
     *
     */
    static final String[] Genres = new String[]{"Action", "Animation", "Comedy", "Documentary", "Family", "Horror", "Crime", "Others"};
    /**
     *
     */
    static final int ADD_REQUEST_CODE = 1000;

    /**
     *
     */
    static final int EDIT_REQUEST_CODE = 1001;

    static final int YEAR_CODE = 1002;

    static final int RATING_CODE = 1003;
    /**
     *
     */
    static final String MOVIE = "movie";

}
