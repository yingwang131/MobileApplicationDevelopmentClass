package com.example.hm4moviedatabase;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class RatingActivity extends AppCompatActivity {

    ArrayList<Movie> movieList;


    TextView tvMovieName;
    TextView tvMovieDescr;
    TextView tvGenre;
    TextView tvRating;
    TextView tvYear;
    TextView tvimdb;


    ImageView ivFirst;
    ImageView ivPrevious;
    ImageView ivNext;
    ImageView ivLast;

    Button btnFinish;

    int currentIndex = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        movieList = getIntent().getParcelableArrayListExtra(Constants.Movie_LIST);
        initiateUI();

        addListeners();
    }

    /**
     *
     */
    private void addListeners() {
        ivFirst.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (movieList.size() > 0) {
                    fillMovieInformation(movieList.get(0));
                    currentIndex = 0;
                }
            }
        });

        ivPrevious.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (movieList.size() > 0) {//assert the movie list is not empty
                    if (currentIndex == 0) {
                        Toast.makeText(RatingActivity.this, "the current movie is the first movie", Toast.LENGTH_LONG).show();
                    } else {
                        fillMovieInformation(movieList.get(--currentIndex));
                    }
                }
            }
        });

        ivNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (movieList.size() > 0) {//assert the movie list is not empty
                    if (currentIndex == movieList.size() - 1) {
                        Toast.makeText(RatingActivity.this, "the current movie is the last movie", Toast.LENGTH_LONG).show();
                    } else {
                        fillMovieInformation(movieList.get(++currentIndex));
                    }
                }
            }
        });

        ivLast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (movieList.size() > 0) {//assert the movie list is not empty
                    fillMovieInformation(movieList.get(movieList.size() - 1));
                    currentIndex = movieList.size() - 1;
                }
            }
        });

        btnFinish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RatingActivity.this.finish();
            }
        });
    }

    /**
     *
     */
    private void initiateUI() {
        setContentView(R.layout.activity_rating);
        tvMovieName = findViewById(R.id.textView_movieNameR);
        tvMovieDescr = findViewById(R.id.textView_descMovieR);
        tvGenre = findViewById(R.id.tv_genraR);
        tvRating = findViewById(R.id.tv_rateR);
        tvYear = findViewById(R.id.tv_yearR);
        tvimdb = findViewById(R.id.tv_imdbR);

        ivFirst = findViewById(R.id.iv_firstMR);
        ivPrevious = findViewById(R.id.iv_previousR);
        ivNext = findViewById(R.id.iv_nextMR);
        ivLast = findViewById(R.id.iv_lastMR);

        btnFinish = findViewById(R.id.button_finishR);
        //show the content
        if (movieList.size() > 0) {
            Movie movie = movieList.get(0);
            fillMovieInformation(movie);
        }

    }

    /**
     * fill movie information into the textviews
     *
     * @param movie
     */
    private void fillMovieInformation(Movie movie) {
        tvMovieName.setText(movie.getName());
        tvMovieDescr.setText(movie.getDescription());
        tvGenre.setText(movie.getGenre());
        tvRating.setText(String.valueOf(movie.getRate()));
        tvYear.setText(String.valueOf(movie.getYear()));
        tvimdb.setText(movie.getImdb());
    }
}
