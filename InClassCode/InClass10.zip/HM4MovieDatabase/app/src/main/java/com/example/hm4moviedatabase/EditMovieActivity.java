package com.example.hm4moviedatabase;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class EditMovieActivity extends AppCompatActivity {


    EditText etMovieName;

    EditText etMovieDescr;

    SeekBar sbRate;

    EditText etYear;

    EditText etImdb;

    Button btnAddMovie;

    TextView tvRate;

    Spinner spinnerGenre;

    int rate;

    String genre;

    String year;

    String imdb;

    String name;

    String describe;

    Movie movie;

    String oldId;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        movie = getIntent().getParcelableExtra(Constants.MOVIE);

        initialUI();

        int itemIdx = indexOfGenre(movie.getGenre());
        oldId = movie.getId();


        //set value list  for genre component
        final ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.support_simple_spinner_dropdown_item, Constants.Genres);
        spinnerGenre.setAdapter(adapter);
        //get the genre type
        spinnerGenre.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
                genre = (String) adapterView.getItemAtPosition(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        spinnerGenre.setSelection(itemIdx);

        //add lisener on seek bar
        sbRate.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean b) {
                rate = progress;
                tvRate.setText(String.valueOf(rate));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        btnAddMovie.setOnClickListener(new Button.OnClickListener() {

            @Override
            public void onClick(View view) {
                //add  movie data into movieList
                name = etMovieName.getText().toString();
                describe = etMovieDescr.getText().toString();
                year = etYear.getText().toString();
                imdb = etImdb.getText().toString();

                //assert the condition of name and describe
                if (validateYear(year)) {
                    Movie movie = new Movie();
                    movie.setDescription(describe);
                    movie.setGenre(genre);
                    movie.setImdb(imdb);
                    movie.setRate(rate);
                    movie.setYear(Integer.valueOf(year));
                    movie.setName(name);
                    movie.setId(oldId);

                    //call firebase API to update the movie
                    FireBaseUtil.updateMovie(movie);
                    //return to main UI
                    Intent intent = new Intent();
                    intent.putExtra(Constants.MOVIE, movie);
                    setResult(Constants.EDIT_REQUEST_CODE, intent);
                    finish();
                } else {
                    Toast.makeText(EditMovieActivity.this, "year must be numbers", Toast.LENGTH_LONG).show();
                }
            }

            private boolean validateYear(String year) {
                for (char val :
                        year.toCharArray()) {
                    if (!Character.isDigit(val)) {
                        return false;
                    }

                }
                return true;
            }
        });


    }

    /**
     * initiate UI
     */
    private void initialUI() {
        setContentView(R.layout.activity_edit_movie);

        btnAddMovie = findViewById(R.id.button_saveChange_edit);

        etMovieName = findViewById(R.id.editText_movieName_edit);

        etMovieDescr = findViewById(R.id.editText_describe_edit);

        sbRate = findViewById(R.id.seekBar_rate_edit);

        spinnerGenre = findViewById(R.id.spinner_genre_edit);

        etYear = findViewById(R.id.editText_year_edit);

        etImdb = findViewById(R.id.editText_imdb_edit);

        tvRate = findViewById(R.id.tv_rate_edit);

        etMovieName.setText(movie.getName());
        etMovieDescr.setText(movie.getDescription());
        etYear.setText(String.valueOf(movie.getYear()));
        etImdb.setText(movie.getImdb());
        tvRate.setText(String.valueOf(movie.getRate()));
        sbRate.setProgress(movie.getRate());
    }

    /**
     * find the position of genre in the genre array
     *
     * @param genre
     * @return
     */
    private int indexOfGenre(String genre) {

        int idx = 0;
        for (String item :
                Constants.Genres) {
            if (genre.equals(item)) {
                return idx;
            }
            idx++;
        }
        return idx;
    }
}
