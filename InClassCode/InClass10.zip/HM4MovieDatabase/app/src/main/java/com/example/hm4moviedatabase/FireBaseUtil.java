package com.example.hm4moviedatabase;

import android.util.Log;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class FireBaseUtil {

    static int numCores = Runtime.getRuntime().availableProcessors();
    static ThreadPoolExecutor executor = new ThreadPoolExecutor(numCores * 2, numCores * 2,
            60L, TimeUnit.SECONDS, new LinkedBlockingQueue<Runnable>());

    /**
     * @param movie
     */
    public static void insertMovie(Movie movie) {
        //fireStore
        //Access a cloud fireStore instance from my activity
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        Map<String, Object> movieMap = movie.toHashMap();
        final CountDownLatch countDownLatch = new CountDownLatch(1);

        db.collection("movies").document(String.valueOf(movie.getId()))
                .set(movieMap).addOnSuccessListener(executor, new OnSuccessListener<Void>() {

            @Override
            public void onSuccess(Void aVoid) {
                countDownLatch.countDown();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                countDownLatch.countDown();
            }
        });
        try {
            countDownLatch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }


    /**
     * @param moviePath
     * @return
     */
    public static Movie queryMovie(String moviePath) {
        final CountDownLatch countDownLatch = new CountDownLatch(1);
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        final Movie movie = new Movie();
        db.collection("movies").document(moviePath)
                .get().addOnCompleteListener(executor, new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        Log.d("demo", document.getData().toString());
                        Movie data = document.toObject(Movie.class);
                        movie.setDescription(data.getDescription());
                        movie.setGenre(data.getGenre());
                        movie.setId(data.getId());
                        movie.setImdb(data.getImdb());
                        movie.setName(data.getName());
                        movie.setRate(data.getRate());
                        movie.setYear(data.getYear());

                    }
                }
                countDownLatch.countDown();
            }
        });

        try {
            countDownLatch.await();

        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            return movie;
        }
    }


    /**
     * @return
     */
    public static List<Movie> queryAll() {
        final CountDownLatch countDownLatch = new CountDownLatch(1);
        final List<Movie> movieList = new ArrayList<>();
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.clearPersistence();

        Task task = db.collection("movies")
                .get();


        task.addOnCompleteListener(executor, new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    for (QueryDocumentSnapshot document : task.getResult()) {
                        if (document.exists()) {
                            Log.d("demo", document.getData().toString());
                            Movie movie = document.toObject(Movie.class);
                            movieList.add(movie);
                        }
                    }
                }
                countDownLatch.countDown();
            }
        });

        try {
            countDownLatch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            return movieList;
        }
    }

    /**
     * @param moviePath
     */
    public static void delMovie(String moviePath) {
        // Try to delete the data
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection("movies").document(moviePath)
                .delete()
                .addOnSuccessListener(executor, new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d("demo", "Document SUCCEFULLY deleted!");
                    }
                });
    }

    /**
     * @param movie
     */
    public static void updateMovie(Movie movie) {
        // Try to update Movie
//        FirebaseFirestore db = FirebaseFirestore.getInstance();
//        Map<String, Object> movieMap = movie.toHashMap();
//        final CountDownLatch countDownLatch = new CountDownLatch(1);
//
//        db.collection("movies").document(String.valueOf(movie.getId()))
//                .set(movieMap).addOnSuccessListener(executor, new OnSuccessListener<Void>() {
//
//            @Override
//            public void onSuccess(Void aVoid) {
//                countDownLatch.countDown();
//            }
//        }).addOnFailureListener(new OnFailureListener() {
//            @Override
//            public void onFailure(@NonNull Exception e) {
//                countDownLatch.countDown();
//            }
//        });
//        try {
//            countDownLatch.await();
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }


        final CountDownLatch countDownLatch = new CountDownLatch(1);
        final List<Movie> movieList = new ArrayList<>();
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.clearPersistence();

        Task task = db.collection("movies").document(movie.getId()).set(movie.toHashMap());


        task.addOnCompleteListener(executor, new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                countDownLatch.countDown();
            }
        });

        try {
            countDownLatch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
        }

    }
}
