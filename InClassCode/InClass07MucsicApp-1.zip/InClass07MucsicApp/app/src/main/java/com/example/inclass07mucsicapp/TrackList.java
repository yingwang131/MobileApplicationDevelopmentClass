package com.example.inclass07mucsicapp;

import java.io.Serializable;

public class TrackList implements Serializable {
    String track_name, artist_name,album_name,updated_time, track_share_url;

    public TrackList() {
    }

    @Override
    public String toString() {
        return "TrackList{" +
                "track_name='" + track_name + '\'' +
                ", artist_name='" + artist_name + '\'' +
                ", album_name='" + album_name + '\'' +
                ", updated_time='" + updated_time + '\'' +
                ", track_share_url='" + track_share_url + '\'' +
                '}';
    }
}
