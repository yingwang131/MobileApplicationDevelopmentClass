package com.example.inclass07mucsicapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.TextView;

import org.apache.commons.io.IOUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    SeekBar seekBar;
    EditText editTextSearch;
    ListView listView;
    TextView setLimit;
    Button search;
    RadioGroup radioGroup;
    ProgressBar progressBar;
    int limit = 10;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        seekBar = (SeekBar)findViewById(R.id.seekBar);
        editTextSearch = (EditText)findViewById(R.id.editText);
        listView = findViewById(R.id.listView);
        setLimit = (TextView) findViewById(R.id.tvLimit);
        search = (Button)findViewById(R.id.buttonSearch);
        radioGroup = findViewById(R.id.radioGroup);

        progressBar = findViewById(R.id.progressBar);
        progressBar.setProgress(0);
        progressBar.setVisibility(View.INVISIBLE);



        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progressInt, boolean b) {
                limit = progressInt + 5;
                setLimit.setText("Limit:" + limit);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

       search.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
                int rdId = radioGroup.getCheckedRadioButtonId();
                if (rdId == R.id.radioButtonTrack){
                    Log.d("demo", "Track");
                    String song_name = editTextSearch.getText().toString();
                    String my_url = "https://api.musixmatch.com/ws/1.1/track.search?apikey=0bd8c933365ddd92fe53488cd2b4c4d3&q="
                            + song_name + "&page_size=" + limit + "&s_track_rating=desc";
                    new GetDataAsync().execute(my_url);
                } else {
                    Log.d("demo", "Artist");
                    String artistName = editTextSearch.getText().toString();
                    String my_url = "https://api.musixmatch.com/ws/1.1/track.search?apikey=0bd8c933365ddd92fe53488cd2b4c4d3&q="
                            + artistName +  "&page_size=" + limit + "s_artist_rating=desc";
                    new GetDataAsync().execute(my_url);
                }


           }
       });

    }

    /**
     * make sure the connection works
     *
     * @return
     */
    private boolean isConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        if (networkInfo == null || !networkInfo.isConnected() ||
                (networkInfo.getType() != ConnectivityManager.TYPE_WIFI
                        && networkInfo.getType() != ConnectivityManager.TYPE_MOBILE)) {
            return false;
        }
        return true;
    }

    public class GetDataAsync extends AsyncTask<String, Void, ArrayList<TrackList>> {

        @Override
        protected ArrayList<TrackList> doInBackground(String... params) {
            HttpURLConnection connection = null;
            ArrayList<TrackList> result = new ArrayList<>();
            try {
                URL url = new URL(params[0]);
                connection = (HttpURLConnection) url.openConnection();
                connection.connect();
                if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    String json = IOUtils.toString(connection.getInputStream(), "UTF8");

                    JSONObject root = new JSONObject(json);
                    JSONObject message = (JSONObject) root.get("message");
                    JSONObject body = (JSONObject) message.get("body");

                    JSONArray rootJSONArray = body.getJSONArray("track_list");

                    for (int i = 0; i < rootJSONArray.length(); i++) {

                        JSONObject tj = rootJSONArray.getJSONObject(i);

                        JSONObject trackJson = tj.getJSONObject("track");

                        TrackList track = new TrackList();

                        track.track_name = trackJson.getString("track_name");
                        track.album_name = trackJson.getString("album_name");
                        track.artist_name = trackJson.getString("artist_name");


                        DateFormat inputFormat = new SimpleDateFormat("yyyy-mm-dd'T'hh:mm:ss'Z'");
                        DateFormat outputFormat = new SimpleDateFormat("mm-dd-yyyy");

                        String inputDateStr=trackJson.getString("updated_time");;
                        Date my_date = inputFormat.parse(inputDateStr);
                        track.updated_time = outputFormat.format(my_date);



                        track.track_share_url = trackJson.getString("track_share_url");

                        result.add(track);
                    }
                }
            } catch (MalformedURLException e){
                e.printStackTrace();
            } catch (IOException e){
                e.printStackTrace();
            } catch (JSONException e){
                e.printStackTrace();
            } catch (ParseException e) {
                e.printStackTrace();
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
            }
            return result;
        }

        @Override
        protected void onPreExecute() {


            progressBar = new ProgressBar(MainActivity.this);
            progressBar.setProgress(0);
            progressBar.setVisibility(View.VISIBLE);



        }

        @Override
        protected void onPostExecute(final ArrayList<TrackList> result) {

            if (result.size() > 0) {
                Log.d("result", String.valueOf(result));
                TrackAdapter adapter = new TrackAdapter(MainActivity.this, R.layout.track_adapter,result);
                listView.setAdapter(adapter);
                listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                        Intent intent = new Intent(Intent.ACTION_VIEW);
                        intent.setData(Uri.parse(result.get(i).track_share_url.toString()));
                        startActivity(intent);
                    }
                });



            }
            else {
                Log.d("demo", "null result");
            }
        }


    }

}
