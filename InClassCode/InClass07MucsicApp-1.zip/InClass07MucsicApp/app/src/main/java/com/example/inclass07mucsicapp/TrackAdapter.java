package com.example.inclass07mucsicapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class TrackAdapter extends ArrayAdapter<TrackList> {

    public TrackAdapter(@NonNull Context context, int resource, @NonNull List<TrackList> objects) {
        super(context, resource, objects);
    }

    public View getView(final int position, @Nullable View convertView, @NonNull ViewGroup parent) {



        TrackList track = getItem(position);
        ViewHolder viewHolder;

        if (convertView == null){
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.track_adapter, parent, false);
            viewHolder = new ViewHolder();

            viewHolder.song = (TextView) convertView.findViewById(R.id.tvTrackName);
            viewHolder.artist = (TextView) convertView.findViewById(R.id.tvArtistName);
            viewHolder.date = (TextView) convertView.findViewById(R.id.tvDate);
            viewHolder.album = (TextView) convertView.findViewById(R.id.tvAlbumName);




            convertView.setTag(viewHolder);
        }

        else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        viewHolder.song.setText("Track: "+track.track_name);
        viewHolder.artist.setText("Artist: "+track.artist_name);
        viewHolder.album.setText("Album: "+track.album_name);
        viewHolder.date.setText("Date: "+track.updated_time.toString());

        return convertView;
    }

    private static class ViewHolder{
        TextView song;
        TextView album;
        TextView artist;
        TextView date;

    }

}

