package com.example.myapplication;


import java.io.Serializable;

public class Photos implements Serializable {
    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    String url;

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    String path;

    public Photos(String url) {
        this.url = url;
    }


    public Photos(String url, String path) {
        this.url = url;
        this.path = path;
    }

    public Photos() {

    }


    @Override
    public String toString() {
        return "Photos{" + "url='" + url + '\'' + '}';
    }
}


