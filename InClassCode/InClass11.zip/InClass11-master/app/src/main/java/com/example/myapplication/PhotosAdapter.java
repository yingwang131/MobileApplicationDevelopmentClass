package com.example.myapplication;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;


import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import java.util.List;

public class PhotosAdapter extends ArrayAdapter<Photos> {
    ImageView iv_photos;

    List<Photos> dataList;

    public PhotosAdapter(@NonNull Context context, int resource, @NonNull List<Photos> objects) {
        super(context, resource, objects);
        this.dataList = objects;
    }

    public View getView(final int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        Photos photos = getItem(position);


        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.photo_adapter, parent, false);

        }
        iv_photos = convertView.findViewById(R.id.iv_photos);
        Picasso.get().load(photos.url).into(iv_photos);

        iv_photos.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {

                Photos photo = (Photos) dataList.get(position);
                deletePhoto(photo.getPath());

                dataList.remove(position);
                notifyDataSetChanged();
                return false;
            }
        });
        return convertView;
    }

    // delete the photo
    public void deletePhoto(String photoPath) {
        FirebaseStorage firebaseStorage = FirebaseStorage.getInstance();
        final StorageReference storageReference = firebaseStorage.getReference();
        final StorageReference imageRepo = storageReference.child(photoPath);
        imageRepo.delete().addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                Log.d("demo", "Document SUCCESSFULLY deleted!");
            }
        });
    }
}
