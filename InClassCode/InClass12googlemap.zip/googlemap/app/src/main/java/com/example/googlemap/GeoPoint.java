package com.example.googlemap;

/**
 * class store the location points
 */
public class GeoPoint {

    /**
     * latitude of the position point
     */
    private String latitude;
    /**
     * longitude of the position point
     */
    private String longitude;

    public GeoPoint() {
        super();
    }

    public GeoPoint(String latitude, String longitude) {
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    @Override
    public String toString() {
        return "GeoPoint{" +
                "latitude='" + latitude + '\'' +
                ", longitude='" + longitude + '\'' +
                '}';
    }

}