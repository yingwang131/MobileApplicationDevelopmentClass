package com.example.inclass09httpconnection;

public class Constants {
    public static final String AUTHORIZATION = "Authorization";
}
