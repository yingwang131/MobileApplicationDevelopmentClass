package com.example.inclass09httpconnection;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.alibaba.fastjson.JSONObject;
import com.example.inclass09httpconnection.po.UserPO;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import static com.example.inclass09httpconnection.LogInActivity.LoginToken;

public class AddEmailActivity extends AppCompatActivity {
    Button send;
    Button cancel;
    EditText email_text;
    EditText subject;
    Spinner spinner;
    ArrayList<String> list;

    TextView selectTo;

    String receiverId;

    Map<String, String> nameMap = new HashMap<>();

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_email);


        spinner = (Spinner) findViewById(R.id.spinner);
        selectTo = findViewById(R.id.tv_select_to);
        subject = findViewById(R.id.et_subject);

        queryReceivers();
        list = new ArrayList<String>();
        selectTo.setText("Select to ");

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String userName = ((TextView) view).getText().toString();
                receiverId = nameMap.get(userName);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        email_text = (EditText) findViewById(R.id.et_email_text_add_email);
        String text = email_text.getText().toString();

        cancel = (Button) findViewById(R.id.btn_cancel_addemail);

        send = (Button) findViewById(R.id.btn_send_addemail);
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences pref = getSharedPreferences(LoginToken, Context.MODE_PRIVATE);
                String token = pref.getString("token", "");

                OkHttpClient client = new OkHttpClient();

                FormBody formBody = new FormBody.Builder()
                        .add("message", email_text.getText().toString())
                        .add("receiver_id", receiverId)
                        .add("subject", subject.getText().toString())
                        .build();

                Request request = new Request.Builder()
                        .addHeader(Constants.AUTHORIZATION, token)
                        .addHeader("Content-Type", "application/x-www-form-urlencoded")
                        .url("http://ec2-18-234-222-229.compute-1.amazonaws.com/api/inbox/add")
                        .post(formBody).build();

                client.newCall(request).enqueue(new Callback() {
                    @Override
                    public void onFailure(Call call, IOException e) {

                    }

                    @Override
                    public void onResponse(Call call, Response response) throws IOException {
                        String data = response.body().string();
                        Log.d("hello", data);
                        Log.d("Add Email OnResponse", "Message Received");

                    }
                });


                finish();
            }
        });


    }

    /**
     * query receivers
     *
     * @return
     */
    public void queryReceivers() {

        SharedPreferences pref = getSharedPreferences(LoginToken, Context.MODE_PRIVATE);
        String token = pref.getString("token", "");

        OkHttpClient client = new OkHttpClient();
        //get registered users
        Request request = new Request.Builder()
                .addHeader(Constants.AUTHORIZATION, token)
                .url("http://ec2-18-234-222-229.compute-1.amazonaws.com/api/users").build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {

            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String data = response.body().string();
                Log.d("hello", data);

                if (response.code() == 200 || response.code() == 201) {
                    JSONObject dataJson = JSONObject.parseObject(data);
                    Object users = dataJson.get("users");
                    if (users != null) {
                        List<UserPO> resultList = JSONObject.parseArray(users.toString(), UserPO.class);

                        for (UserPO user : resultList) {
                            list.add(user.getFullName());
                            nameMap.put(user.getFullName(), user.getId());
                        }

                        Collections.sort(list);
                        new Handler(Looper.getMainLooper()).post(new Runnable() {
                            @Override
                            public void run() {
                                ArrayAdapter<String> adapter = new ArrayAdapter<String>(AddEmailActivity.this,
                                        android.R.layout.simple_spinner_item, list);


                                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                                spinner.setAdapter(adapter);
                            }
                        });


                    }
                }
            }
        });


    }
}


