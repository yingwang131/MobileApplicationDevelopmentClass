package com.example.inclass05http;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Base64;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;


/**
 * main class of app
 */
public class MainActivity extends AppCompatActivity {
    TextView textView_search;
    Button button_go;
    ProgressBar pb;
    ImageView imageView;
    ImageView imgForward;
    ImageView imgBackward;
    /**
     * handler in the UI thread, which is responsible to update image
     */
    Handler handler;
    /**
     * store url list
     */
    List<String> urlList = new ArrayList<>();
    /**
     * store the current index of image
     */
    int currentIndex = 0;
    /**
     * flag indicates whether it is the first time load image or not
     */
    Boolean isFirst = Boolean.FALSE;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView_search = findViewById(R.id.textView_search);
        button_go = findViewById(R.id.button_go);
        pb = findViewById(R.id.progressBar);
        imageView = findViewById(R.id.imageView3);
        imgBackward = findViewById(R.id.img_backward);
        imgForward = findViewById(R.id.img_forward);


        button_go.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view) {
                new GetKeyWordsAPI().execute("http://dev.theappsdr.com/apis/photos/keywords.php");

            }
        });


        handler = new Handler(new Handler.Callback() {
            @Override
            public boolean handleMessage(@NonNull Message message) {
                System.out.println("name of current thread " + Thread.currentThread().getName() + "-----------------");
                pb.setVisibility(View.INVISIBLE);
                Log.d("demo", "Message received ying");

                Bundle bundle = message.getData();
                Boolean flag = bundle.getBoolean("flag");

                if (flag) {

                    imgForward.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            int index = (++currentIndex) % urlList.size();
                            pb.setVisibility(ProgressBar.VISIBLE);
                            new LoadImageTask().execute(urlList.get(index), isFirst.toString());

                        }
                    });


                    imgBackward.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            int index = (--currentIndex) % urlList.size();
                            urlList.get(index);
                            pb.setVisibility(ProgressBar.VISIBLE);
                            new LoadImageTask().execute(urlList.get(index), isFirst.toString());
                        }
                    });
                }
                if ("200".equals(bundle.getString("success"))) {
                    String bitmapStr = bundle.getString("image");
                    imageView.setImageBitmap(stringToBitmap(bitmapStr));
                }
                return true;
            }
        });

    }

    /**
     * task for getting the url list correspond to the keyword
     */
    public class GetKeyWordsAPI extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... strings) {
            HttpURLConnection connection = null;
            StringBuilder stringBuilder = new StringBuilder();
            InputStream inputStream = null;
            String result = "";
            try {
                URL url = new URL(strings[0]);
                Log.d("Connection MyApp", "Connection URL: " + strings[0]);
                connection = (HttpURLConnection) url.openConnection();
                Log.d("Connection MyApp", "Connection Established");
                inputStream = connection.getInputStream();
                Log.d("Connection MyApp", "Read");
                BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
                String line = "";

                while ((line = reader.readLine()) != null) {
                    stringBuilder.append(line);
                    Log.d("demo", "keywords " + line.toString());
                }
                result = stringBuilder.toString().trim();
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (inputStream != null) {
                    try {
                        inputStream.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                if (connection != null) {
                    connection.disconnect();
                }
            }
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            final String[] listItems = s.split(";");
            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
            builder.setTitle("Choose a Keyword");

            builder.setItems(listItems, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    //Toast.makeText(this, "Position: " + which + " Value: " + listItems[which], Toast.LENGTH_LONG).show();
                    textView_search.setText(listItems[which]);
                    //get parameter
                    String keyword = listItems[which];
                    String imageAddressUrl = "http://dev.theappsdr.com/apis/photos/index.php";
                    new GetImageURLAPI().execute(imageAddressUrl, keyword);

                }
            });

            AlertDialog dialog = builder.create();
            dialog.show();

        }


    }

    /**
     * class for getting the url list of one catelog
     */
    public class GetImageURLAPI extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... strings) {
            String urlStr = strings[0];
            String keyWord = strings[1];
            HttpURLConnection connection = null;
            StringBuilder stringBuilder = new StringBuilder();
            InputStream inputStream = null;
            String result = "";
            try {
                URL url = new URL(urlStr + "?keyword=" + keyWord);
                Log.d("Connection MyApp", "Connection URL: " + strings[0]);
                connection = (HttpURLConnection) url.openConnection();
                Log.d("Connection MyApp", "Connection Established");
                inputStream = connection.getInputStream();
                Log.d("Connection MyApp", "Read");
                BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
                String line = "";

                while ((line = reader.readLine()) != null) {
                    stringBuilder.append(line);
                    stringBuilder.append(";");
                    Log.d("demo", "keywords " + line.toString());
                }
                stringBuilder.deleteCharAt(stringBuilder.length() - 1);
                result = stringBuilder.toString().trim();
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (inputStream != null) {
                    try {
                        inputStream.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                if (connection != null) {
                    connection.disconnect();
                }
            }
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if (s != null && s.length() > 0) {
                final String[] imageUrls = s.split(";");
                isFirst = Boolean.TRUE;
                //reset currentIndex
                currentIndex = 0;
                //clear old url list
                urlList.clear();
                //store the url list
                for (String imageUrl :
                        imageUrls) {
                    urlList.add(imageUrl);
                }
                //load the first image
                String url = imageUrls[0];
                pb.setVisibility(ProgressBar.VISIBLE);
                new LoadImageTask().execute(url, isFirst.toString());

            } else {
                imageView.setImageBitmap(null);
                Toast toast = Toast.makeText(MainActivity.this, "No Images Found", Toast.LENGTH_SHORT);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();
            }

        }

    }

    /**
     * class for loading image from url
     */
    public class LoadImageTask extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... strings) {
            String imageUrl = strings[0];
            boolean flag = Boolean.parseBoolean(strings[1]);
            try {
                Bitmap bitmap = returnBitMap(imageUrl);
                Message message = new Message();
                Bundle bundle = new Bundle();
//            bundle.putDouble("calculate", compl);
                bundle.putString("success", "200");
                bundle.putString("image", bitmapToString(bitmap));
                bundle.putBoolean("flag", flag);
                message.setData(bundle);
                handler.sendMessage(message);
                if (flag == Boolean.TRUE) {
                    isFirst = Boolean.FALSE;
                }
            } catch (IOException e) {
                e.printStackTrace();
                Log.e("error", "could not load the image from this address:" + imageUrl);
            }
            return null;
        }
    }

    /**
     * load the image from the url address
     *
     * @param url
     * @return
     */
    public Bitmap returnBitMap(String url) throws IOException {

        URL myFileUrl = null;

        Bitmap bitmap = null;

        try {

            myFileUrl = new URL(url);

        } catch (MalformedURLException e) {

            e.printStackTrace();

        }

        InputStream is = null;
        HttpURLConnection conn = null;
        try {

            conn = (HttpURLConnection) myFileUrl.openConnection();

            conn.setDoInput(true);

            conn.connect();

            is = conn.getInputStream();

            bitmap = BitmapFactory.decodeStream(is);


        } catch (IOException e) {

            e.printStackTrace();

        } finally {
            if (is != null) {
                is.close();
            }
            if (conn != null) {
                conn.disconnect();
            }
        }

        return bitmap;

    }


    /**
     * transfer bitmap to string encode by base64
     *
     * @param string
     * @return
     */
    public static Bitmap stringToBitmap(String string) {
        Bitmap bitmap = null;
        try {
            byte[] bitmapArray = Base64.decode(string, Base64.DEFAULT);
            bitmap = BitmapFactory.decodeByteArray(bitmapArray, 0, bitmapArray.length);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return bitmap;
    }

    /**
     * transfer string encoded by base64 to bitmap
     *
     * @param bitmap
     * @return
     */
    public static String bitmapToString(Bitmap bitmap) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos);
        byte[] imgBytes = baos.toByteArray();
        return Base64.encodeToString(imgBytes, Base64.DEFAULT);
    }
}
