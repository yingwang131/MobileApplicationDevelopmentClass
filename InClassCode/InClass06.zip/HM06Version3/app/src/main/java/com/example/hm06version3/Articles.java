package com.example.hm06version3;

public class Articles {
    String title, description, publishedAt, urlToImage;

    public Articles() {
    }

    @Override
    public String toString() {
        return "Articles{" +
                "title='" + title + '\'' +
                ", description='" + description + '\'' +
                ", publishedAt='" + publishedAt + '\'' +
                ", urlToImage='" + urlToImage + '\'' +
                '}';
    }
}
