package com.example.hm06version3;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import org.apache.commons.io.IOUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ArrayList<Articles> articles = new ArrayList<>();
    public static int idx = 0;
    public String selectCategory;
    ProgressDialog progressDialog;
    ImageView imP;
    ImageView imN;
    ImageView imageView;

    TextView tvCategory;
    TextView tvDescription;
    TextView tvCounter;
    TextView tvpublishedAt;
    TextView tvTitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imP = findViewById(R.id.iv_prev);
        imN = findViewById(R.id.iv_next);
        imN.setVisibility(View.INVISIBLE);
        imP.setVisibility(View.INVISIBLE);

        imageView = findViewById(R.id.iv_pic);

        tvCategory = findViewById(R.id.tv_Show);
        tvDescription = findViewById(R.id.tv_description);
        tvCounter = findViewById(R.id.tv_page);
        tvpublishedAt = findViewById(R.id.tv_date);
        tvTitle = findViewById(R.id.tv_title);


        tvCounter.setText("");
        tvCategory.setVisibility(View.VISIBLE);
        tvTitle.setVisibility(View.INVISIBLE);
        tvDescription.setVisibility(View.INVISIBLE);
        tvpublishedAt.setVisibility(View.INVISIBLE);
        imageView.setVisibility(View.INVISIBLE);

        final ArrayList<String> items = new ArrayList<String>();
        items.add("Business");
        items.add("Entertainment");
        items.add("General");
        items.add("Health");
        items.add("Science");
        items.add("Sports");
        items.add("Technology");

        /**
         * implement the AlertDialog
         */
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Choose Category")
                .setItems(items.toArray(new CharSequence[items.size()]), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        selectCategory = items.get(which);

                        TextView tvCategory = findViewById(R.id.tv_Show);
                        tvCategory.setText(selectCategory);
                        //https://newsapi.org/v2/top-headlines?category=business&apiKey=c2f3d9e9c24140f59af7390a9e6cd327
                        String my_url = "https://newsapi.org/v2/top-headlines?category=" + selectCategory + "&apiKey=c2f3d9e9c24140f59af7390a9e6cd327";
                        new GetDataAsync().execute(my_url);

                        Log.d("Alert Dialog Selected", selectCategory);
                        Log.d("Alert Dialog Selected", String.valueOf(which));
                    }
                });

        final AlertDialog alertDialog = builder.create();
        findViewById(R.id.button_select).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isConnected()) {
                    alertDialog.show();
                } else {
                    Toast.makeText(MainActivity.this, "Check Internet", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    /**
     * make sure the connection works
     * @return
     */
    private boolean isConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        if (networkInfo == null || !networkInfo.isConnected() ||
                (networkInfo.getType() != ConnectivityManager.TYPE_WIFI
                        && networkInfo.getType() != ConnectivityManager.TYPE_MOBILE)) {
            return false;
        }
        return true;
    }

    /**
     * Implement the AsyncTask task and parsing the Json data
     */
    private class GetDataAsync extends AsyncTask<String, Void, ArrayList<Articles>> {
        @Override
        protected ArrayList<Articles> doInBackground(String... params) {
            HttpURLConnection connection = null;
            ArrayList<Articles> result = new ArrayList<Articles>();
            try {
                URL url = new URL(params[0]);
                connection = (HttpURLConnection) url.openConnection();
//                connection.connect();
//                if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
//                    result = ArticlesParser.PtoString(connection.getInputStream(), "UTF-8");
//
//
//                }

                String json = IOUtils.toString(connection.getInputStream(), "UTF-8");
                JSONObject root = new JSONObject(json);
                JSONArray articles = root.getJSONArray("articles");

                for (int i = 0; i < articles.length(); i++) {
                    JSONObject articlesJson = articles.getJSONObject(i);
                    Articles article = new Articles();
                    article.title = articlesJson.getString("title");
                    article.description = articlesJson.getString("description");
                    article.urlToImage = articlesJson.getString("urlToImage");
                    article.publishedAt = articlesJson.getString("publishedAt");
                    result.add(article);
                    Log.d("articles", String.valueOf(article));
                }

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
            }
            return result;
        }


        /**
         * the PreExecute should set up he the related fields are InVisible;
         */
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            Log.d("start processing", "Before PD");

            progressDialog = new ProgressDialog(MainActivity.this);
            progressDialog.setCancelable(false);
            progressDialog.setTitle("Loading...");
            progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            progressDialog.setProgress(0);
            progressDialog.show();


            tvCategory.setVisibility(View.INVISIBLE);
            tvTitle.setVisibility(View.INVISIBLE);
            tvDescription.setVisibility(View.INVISIBLE);
            imageView.setVisibility(View.INVISIBLE);


        }

        /**
         * for the PostExecute should set up related fields to VISIBLE and setTest to the realted TexView + image
         * @param finalresult
         */

        @Override
        protected void onPostExecute(ArrayList<Articles> finalresult) {
            if (finalresult.size() > 0) {
                Log.d("result", String.valueOf(finalresult));
                progressDialog.hide();

                imN.setVisibility(View.VISIBLE);
                imP.setVisibility(View.VISIBLE);

                Log.d("demo", "onPostExecute is " + finalresult);
                articles = finalresult;


                tvCounter.setText(idx + 1 + " out of " + articles.size());
                TextView tvCategory = findViewById(R.id.tv_Show);

                tvCategory.setVisibility(View.VISIBLE);
                tvpublishedAt.setVisibility(View.VISIBLE);
                tvDescription.setVisibility(View.VISIBLE);
                tvTitle.setVisibility(View.VISIBLE);
                tvCounter.setVisibility(View.VISIBLE);
                imageView.setVisibility(View.VISIBLE);

                tvTitle.setText(articles.get(idx).title);
                tvDescription.setText(articles.get(idx).description);
                tvpublishedAt.setText(articles.get(idx).publishedAt);
                Picasso.get().load(articles.get(idx).urlToImage).into(imageView);

                imP.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (idx == 0) {
                            idx = articles.size() - 1;
                            tvTitle.setText(articles.get(idx).title);
                            tvDescription.setText(articles.get(idx).description);
                            tvpublishedAt.setText(articles.get(idx).publishedAt);
                            Picasso.get().load(articles.get(idx).urlToImage).resize(300, 200).into(imageView);
                            tvCounter.setText(idx + 1 + " out of " + articles.size());
                        } else {
                            idx -= 1;
                            tvTitle.setText(articles.get(idx).title);
                            tvDescription.setText(articles.get(idx).description);
                            tvpublishedAt.setText(articles.get(idx).publishedAt);
                            Picasso.get().load(articles.get(idx).urlToImage).resize(300, 200).into(imageView);
                            tvCounter.setText(idx + 1 + " out of " + articles.size());
                        }

                    }
                });

                imN.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (idx == articles.size() - 1) {
                            idx = 0;
                            tvTitle.setText(articles.get(idx).title);
                            tvDescription.setText(articles.get(idx).description);
                            tvpublishedAt.setText(articles.get(idx).publishedAt);
                            if (articles.get(idx).urlToImage != null && articles.get(idx).urlToImage.trim().length() > 0) {
                                Picasso.get().load(articles.get(idx).urlToImage).resize(300, 200).into(imageView);
                            }
                            tvCounter.setText(idx + 1 + " out of " + articles.size());
                        } else {
                            idx += 1;
                            tvTitle.setText(articles.get(idx).title);
                            tvDescription.setText(articles.get(idx).description);
                            tvpublishedAt.setText(articles.get(idx).publishedAt);
                            if (articles.get(idx).urlToImage != null && articles.get(idx).urlToImage.trim().length() > 0) {
                                Picasso.get().load(articles.get(idx).urlToImage).resize(300, 200).into(imageView);
                            }
                            tvCounter.setText(idx + 1 + " out of " + articles.size());

                        }
                    }
                });
            }

        }


    }
}


